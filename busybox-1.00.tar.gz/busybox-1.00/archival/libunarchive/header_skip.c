#include <stdio.h>
#include "unarchive.h"

extern void header_skip(const file_header_t *file_header)
{
	return;
}
