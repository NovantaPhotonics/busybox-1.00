#include <stdlib.h>
#include <string.h>
#include "unarchive.h"
#include "libbb.h"

extern llist_t *llist_add_to(llist_t *old_head, char *new_item)
{
	llist_t *new_head;

	new_head = xmalloc(sizeof(llist_t));
	new_head->data = new_item;
	new_head->link = old_head;

	return(new_head);
}
